/*eslint-env browser*/
/*eslint "no-console": "off"*/
/*global $*/

$(document).ready(function () {
	loadMainPage();
	$(".list-group-item").click(function (e) {
		e.preventDefault();
		$('#main-page').hide();
		$('#locations').hide();
		console.log($(this).data('rel'));
		$('#' + $(this).data('rel')).show();
	});
	$(".link-bottom").click(function (e) {
		e.preventDefault();
		$('#game-info').hide();
		$('#main-page').hide();
		$('#chat').hide();
		$('#locations').hide();
		$('#game-info-10').hide();
		$('#game-info-11').hide();
		$('#game-info-12').hide();
		$('.container-maps').hide();
		$('#' + $(this).data('rel')).show();
	});

	$('#previous-month').click(function () {
		var currentMonth = $('#month').val();
		var previousmonth = getCurrentTextMonth(Number(currentMonth-1));
		$('#month').text(previousmonth);
		$('#month').val(currentMonth-1);
	});
	$('#next-month').click(function () {
		var month = $('#month').val();
		var nextmonth = getCurrentTextMonth(Number(month)+1);
		$('#month').text(nextmonth);
		$('#month').val(Number(month)+1);
	});
});

function loadMainPage() {

	$('.main-page').show();

	var month = getCurrentMonth();
	var monthName = getCurrentTextMonth(month);
	$('#month').text(monthName);
	$('#month').val(month);
}

function getCurrentMonth() {
	var currentDate = new Date();
	var currentMonth = currentDate.getMonth();

	return currentMonth;
}

function getCurrentTextMonth(month) {
	
	var monthNames = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
  "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
	
	return monthNames[month];

}
